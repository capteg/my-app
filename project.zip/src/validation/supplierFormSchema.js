// src/validation/supplierFormSchema.js
import * as yup from 'yup';

const phoneRegExp = /^\+[1-9]\d{1,14}$/;
const minExpiryDate = new Date(Date.now() + (90 * 24 * 60 * 60 * 1000)); // 3 months from now

export const supplierFormSchema = yup.object().shape({
  // Step 1: Contact
  companyName: yup
    .string()
    .required('Company name is required')
    .min(2, 'Company name must be at least 2 characters'),
  email: yup
    .string()
    .email('Please enter a valid email')
    .required('Email is required'),
  whatsappNumber: yup
    .string()
    .matches(phoneRegExp, 'Please enter a valid international phone number')
    .required('WhatsApp number is required'),

  // Step 2: Product Details
  productCategory: yup
    .string()
    .oneOf(['skincare', 'hairCare', 'bodyCare', 'sunCare', 'decorativeCosmetics'], 'Please select a valid category')
    .required('Product category is required'),
  brandTier: yup
    .string()
    .oneOf(['premium', 'midRange', 'budget'], 'Please select a valid brand tier')
    .required('Brand tier is required'),
  expiryDate: yup
    .date()
    .min(minExpiryDate, 'Expiry date must be at least 3 months from now')
    .required('Expiry date is required'),
  quantity: yup
    .number()
    .positive('Quantity must be greater than 0')
    .required('Quantity is required'),
  unit: yup
    .string()
    .oneOf(['pieces'], 'Please select a valid unit')
    .required('Unit is required'),
  minPriceExpectation: yup
    .number()
    .positive('Price must be greater than 0')
    .required('Minimum price expectation is required'),

  // Step 3: Documentation
  files: yup
  .array()
  .of(
    yup.mixed().test('fileType', 'Invalid file format', (file) => {
      if (!file) return false;
      const supportedFormats = ['application/pdf', 'image/jpeg', 'image/png', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'];
      return supportedFormats.includes(file.type);
    })
  )
  .min(1, 'At least one file is required')
  .required('At least one file is required'),
  batchNumbers: yup
    .string()
    .required('Batch numbers are required'),
  storageConditions: yup
    .string()
    .required('Storage conditions are required'),
});