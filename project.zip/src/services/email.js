import emailjs from '@emailjs/browser';

const EMAIL_SERVICE_ID = import.meta.env.VITE_EMAILJS_SERVICE_ID;
const EMAIL_TEMPLATE_ID = import.meta.env.VITE_EMAILJS_TEMPLATE_ID;
const EMAIL_PUBLIC_KEY = import.meta.env.VITE_EMAILJS_PUBLIC_KEY;

export const sendConfirmationEmail = async (formData) => {
  try {
    const templateParams = {
      to_email: formData.email,
      company_name: formData.companyName,
      category: formData.category,
      submission_date: new Date().toLocaleDateString()
    };

    const response = await emailjs.send(
      EMAIL_SERVICE_ID,
      EMAIL_TEMPLATE_ID,
      templateParams,
      EMAIL_PUBLIC_KEY
    );

    return response;
  } catch (error) {
    console.error('Email Service Error:', error);
    throw new Error('Failed to send confirmation email');
  }
};