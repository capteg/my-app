// src/components/forms/SupplierFormWrapper.jsx
import React from 'react';
import PropTypes from 'prop-types';
import SupplierForm from './SupplierForm';

const SupplierFormWrapper = ({ onClose }) => {
  const handleSubmit = async (formData) => {
    try {
      console.log('Form submission started', formData);
      
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Log success
      console.log('Form submission successful');
      
      return true;
    } catch (error) {
      console.error('Form submission error:', error);
      throw error;
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto">
      <div className="flex items-center justify-center min-h-screen px-4 pt-4 pb-20 text-center sm:block sm:p-0">
        {/* Background overlay */}
        <div 
          className="fixed inset-0 transition-opacity bg-gray-500 bg-opacity-75" 
          aria-hidden="true"
          onClick={onClose}
        ></div>

        {/* Modal panel */}
        <div className="inline-block align-bottom bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-4xl sm:w-full">
          <SupplierForm 
            onClose={onClose} 
            onSubmit={handleSubmit}
          />
        </div>
      </div>
    </div>
  );
};

SupplierFormWrapper.propTypes = {
  onClose: PropTypes.func.isRequired
};

export default SupplierFormWrapper;