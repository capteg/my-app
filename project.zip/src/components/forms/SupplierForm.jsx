// @ts-nocheck
// src/components/forms/SupplierForm.jsx
import React, { useState, useCallback } from 'react';
import PropTypes from 'prop-types';
import { useFormik } from 'formik';
import { supplierFormSchema } from '../../validation/supplierFormSchema';
import { PRODUCT_CATEGORIES, BRAND_TIERS, UNITS } from '../../constants/data';
import BulkUpload from '../upload/BulkUpload';

/**
 * @typedef {Object} SupplierFormProps
 * @property {Function} onClose - Function to close the form modal
 * @property {Function} onSubmit - Function to handle form submission
 */

/**
 * SupplierForm component for collecting supplier information
 * @param {SupplierFormProps} props
 */
const SupplierForm = ({ onClose, onSubmit }) => {
  const [step, setStep] = useState(1);
  const [files, setFiles] = useState([]);
  const [isFormComplete, setIsFormComplete] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const formik = useFormik({
    initialValues: {
      companyName: '',
      email: '',
      whatsappNumber: '',
      productCategory: '',
      brandTier: '',
      expiryDate: '',
      quantity: '',
      unit: 'pieces',
      minPriceExpectation: '',
      batchNumbers: '',
      storageConditions: '',
      currentLocation: '',
      files: [],
      additionalNotes: ''
    },
    validationSchema: supplierFormSchema,
    onSubmit: async (values) => {
      if (isSubmitting) return;
      
      try {
        setIsSubmitting(true);
        console.log('Form submission started');
        const formData = {
          ...values,
          files: files // Use the files state instead of values.files
        };
        await onSubmit(formData);
        setIsFormComplete(true);
        console.log('Form submission successful');

        // Reset and close form after delay
        setTimeout(() => {
          setIsFormComplete(false);
          formik.resetForm();
          setFiles([]);
          setStep(1);
          onClose();
      }, 3000);
      } catch (error) {
        console.error('Form submission error:', error);
      } finally {
        setIsSubmitting(false);
      }
    }
  });

  const handleFileChange = useCallback((newFiles) => {
    setFiles(newFiles);
  }, []);

  const validateStep = () => {
    const fieldsToValidate = {
      1: ['companyName', 'email', 'whatsappNumber'],
      2: ['productCategory', 'brandTier', 'expiryDate', 'quantity', 'unit', 'minPriceExpectation'],
      3: ['batchNumbers', 'storageConditions', 'files'] // Added 'files' here
    }[step];
  
    const errors = {};
    fieldsToValidate.forEach(field => {
      try {
        supplierFormSchema.fields[field].validateSync(formik.values[field]);
      } catch (error) {
        errors[field] = error.message;
      }
    });
  
    return Object.keys(errors).length === 0;
  };

  const handleNext = () => {
    if (validateStep()) {
      setStep(step + 1);
    } else {
      formik.validateForm();
    }
  };

  const renderStep = () => {
    switch (step) {
      case 1:
        return (
          <div className="space-y-4">
            <div>
              <label htmlFor="companyName" className="form-label">
                Company Name
                <span className="text-red-500">*</span>
              </label>
              <input
                id="companyName"
                name="companyName"
                type="text"
                onChange={formik.handleChange}
                onBlur={formik.handleBlur}
                value={formik.values.companyName}
                className={`form-input ${
                  formik.touched.companyName && formik.errors.companyName ? 'error' : ''
                }`}
                autoComplete="organization"
              />
              {formik.touched.companyName && formik.errors.companyName && (
                <p className="error-message">{formik.errors.companyName}</p>
              )}
            </div>

            <div>
              <label htmlFor="email" className="form-label">
                Email
                <span className="text-red-500">*</span>
              </label>
              <input
                id="email"
                name="email"
                type="email"
                onChange={formik.handleChange}
                onBlur={formik.handleBlur}
                value={formik.values.email}
                className={`form-input ${
                  formik.touched.email && formik.errors.email ? 'error' : ''
                }`}
                autoComplete="email"
              />
              {formik.touched.email && formik.errors.email && (
                <p className="error-message">{formik.errors.email}</p>
              )}
            </div>

            <div>
              <label htmlFor="whatsappNumber" className="form-label">
                WhatsApp Business Number
                <span className="text-red-500">*</span>
              </label>
              <input
                id="whatsappNumber"
                name="whatsappNumber"
                type="tel"
                onChange={formik.handleChange}
                onBlur={formik.handleBlur}
                value={formik.values.whatsappNumber}
                className={`form-input ${
                  formik.touched.whatsappNumber && formik.errors.whatsappNumber ? 'error' : ''
                }`}
                placeholder="+1234567890"
                autoComplete="tel"
              />
              {formik.touched.whatsappNumber && formik.errors.whatsappNumber && (
                <p className="error-message">{formik.errors.whatsappNumber}</p>
              )}
            </div>
          </div>
        );

      case 2:
        return (
          <div className="space-y-4">
            <div>
              <label htmlFor="productCategory" className="form-label">
                Product Category
                <span className="text-red-500">*</span>
              </label>
              <select
                id="productCategory"
                name="productCategory"
                onChange={formik.handleChange}
                onBlur={formik.handleBlur}
                value={formik.values.productCategory}
                className={`form-select w-full px-3 py-2 border rounded-md shadow-sm focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 ${
                  formik.touched.productCategory && formik.errors.productCategory ? 'border-red-500' : 'border-gray-300'
                }`}
              >
                <option value="">Select category</option>
                {PRODUCT_CATEGORIES.map(category => (
                  <option key={category.value} value={category.value}>
                    {category.label}
                  </option>
                ))}
              </select>
              {formik.touched.productCategory && formik.errors.productCategory && (
                <p className="error-message">{formik.errors.productCategory}</p>
              )}
            </div>

            <div>
              <label htmlFor="brandTier" className="form-label">
                Brand Tier
                <span className="text-red-500">*</span>
              </label>
              <select
                id="brandTier"
                name="brandTier"
                onChange={formik.handleChange}
                onBlur={formik.handleBlur}
                value={formik.values.brandTier}
                className={`form-select w-full px-3 py-2 border rounded-md shadow-sm focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 ${
                  formik.touched.productCategory && formik.errors.productCategory ? 'border-red-500' : 'border-gray-300'
                }`}
              >
                <option value="">Select tier</option>
                {BRAND_TIERS.map(tier => (
                  <option key={tier.value} value={tier.value}>
                    {tier.label}
                  </option>
                ))}
              </select>
              {formik.touched.brandTier && formik.errors.brandTier && (
                <p className="error-message">{formik.errors.brandTier}</p>
              )}
            </div>

            <div>
              <label htmlFor="expiryDate" className="form-label">
                Expiry Date
                <span className="text-red-500">*</span>
              </label>
              <input
                id="expiryDate"
                name="expiryDate"
                type="date"
                onChange={formik.handleChange}
                onBlur={formik.handleBlur}
                value={formik.values.expiryDate}
                className={`form-input ${
                  formik.touched.expiryDate && formik.errors.expiryDate ? 'error' : ''
                }`}
                min={new Date(Date.now() + (90 * 24 * 60 * 60 * 1000)).toISOString().split('T')[0]}
              />
              {formik.touched.expiryDate && formik.errors.expiryDate && (
                <p className="error-message">{formik.errors.expiryDate}</p>
              )}
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label htmlFor="quantity" className="form-label">
                  Quantity
                  <span className="text-red-500">*</span>
                </label>
                <input
                  id="quantity"
                  name="quantity"
                  type="number"
                  min="1"
                  onChange={formik.handleChange}
                  onBlur={formik.handleBlur}
                  value={formik.values.quantity}
                  className={`form-input ${
                    formik.touched.quantity && formik.errors.quantity ? 'error' : ''
                  }`}
                />
                {formik.touched.quantity && formik.errors.quantity && (
                  <p className="error-message">{formik.errors.quantity}</p>
                )}
              </div>

              <div>
                <label htmlFor="unit" className="form-label">
                  Unit
                  <span className="text-red-500">*</span>
                </label>
                <select
                  id="unit"
                  name="unit"
                  onChange={formik.handleChange}
                  onBlur={formik.handleBlur}
                  value={formik.values.unit}
                  className={`form-select w-full px-3 py-2 border rounded-md shadow-sm focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 ${
                    formik.touched.productCategory && formik.errors.productCategory ? 'border-red-500' : 'border-gray-300'
                  }`}
                >
                  {UNITS.map(unit => (
                    <option key={unit.value} value={unit.value}>
                      {unit.label}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div>
              <label htmlFor="minPriceExpectation" className="form-label">
                Minimum Price Expectation (€ per unit)
                <span className="text-red-500">*</span>
              </label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 transform -translate-y-1/2">€</span>
                <input
                  id="minPriceExpectation"
                  name="minPriceExpectation"
                  type="number"
                  min="0.01"
                  step="0.01"
                  onChange={formik.handleChange}
                  onBlur={formik.handleBlur}
                  value={formik.values.minPriceExpectation}
                  className={`form-input pl-8 ${
                    formik.touched.minPriceExpectation && formik.errors.minPriceExpectation ? 'error' : ''
                  }`}
                />
              </div>
              {formik.touched.minPriceExpectation && formik.errors.minPriceExpectation && (
                <p className="error-message">{formik.errors.minPriceExpectation}</p>
              )}
            </div>
          </div>
        );

        case 3:
          return (
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-medium text-gray-900 mb-2">
                  Upload Documents
                  <span className="text-red-500">*</span>
                </h3>
                <BulkUpload
                  onFilesSelected={(newFiles) => {
                    handleFileChange(newFiles);
                    formik.setFieldValue('files', newFiles);
                  }}
                  currentFiles={files} // Use the files state instead of formik.values.files
                  error={formik.touched.files && formik.errors.files}
                  isFormComplete={isFormComplete}
                />
              </div>
  
              <div className="space-y-4">
                <div>
                  <label htmlFor="batchNumbers" className="form-label">
                    Batch Numbers
                    <span className="text-red-500">*</span>
                  </label>
                  <input
                    id="batchNumbers"
                    name="batchNumbers"
                    type="text"
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                    value={formik.values.batchNumbers}
                    className={`form-input ${
                      formik.touched.batchNumbers && formik.errors.batchNumbers ? 'error' : ''
                    }`}
                  />
                  {formik.touched.batchNumbers && formik.errors.batchNumbers && (
                    <p className="error-message">{formik.errors.batchNumbers}</p>
                  )}
                </div>
  
                <div>
                  <label htmlFor="storageConditions" className="form-label">
                    Storage Conditions
                    <span className="text-red-500">*</span>
                  </label>
                  <textarea
                    id="storageConditions"
                    name="storageConditions"
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                    value={formik.values.storageConditions}
                    className={`form-textarea ${
                      formik.touched.storageConditions && formik.errors.storageConditions ? 'error' : ''
                    }`}
                    rows={3}
                  />
                  {formik.touched.storageConditions && formik.errors.storageConditions && (
                    <p className="error-message">{formik.errors.storageConditions}</p>
                  )}
                </div>
  
                <div>
                  <label htmlFor="currentLocation" className="form-label">
                    Current Storage Location
                  </label>
                  <input
                    id="currentLocation"
                    name="currentLocation"
                    type="text"
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                    value={formik.values.currentLocation}
                    className="form-input"
                  />
                </div>
  
                <div>
                  <label htmlFor="additionalNotes" className="form-label">
                    Additional Notes
                  </label>
                  <textarea
                    id="additionalNotes"
                    name="additionalNotes"
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                    value={formik.values.additionalNotes}
                    className="form-textarea"
                    rows={3}
                  />
                </div>
              </div>
            </div>
          );
        default:
          return null;
      }
    };
  
    return (
      <div className="bg-white rounded-xl shadow-lg max-w-2xl mx-auto">
        {/* Header with steps */}
        <div className="border-b px-6 py-4">
          <div className="flex justify-between items-center">
            <div className="flex space-x-8">
              {['Contact', 'Product Details', 'Documentation'].map((label, index) => (
                <div
                  key={index}
                  className={`flex items-center ${index + 1 === step ? 'text-blue-600' : 'text-gray-400'}`}
                >
                  <div
                    className={`w-8 h-8 rounded-full flex items-center justify-center border-2 
                      ${index + 1 === step ? 'border-blue-600 bg-blue-50' : 'border-gray-300'}`}
                  >
                    {index + 1}
                  </div>
                  <span className="ml-2">{label}</span>
                </div>
              ))}
            </div>
            <button
              onClick={onClose}
              className={`text-gray-400 hover:text-gray-600 ${
                isSubmitting || isFormComplete ? 'opacity-50 cursor-not-allowed' : ''
              }`}
              type="button"
              disabled={isSubmitting || isFormComplete}
            >
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>
        </div>
    
        {/* Form */}
        <form onSubmit={formik.handleSubmit} className="p-6">
          {renderStep()}
          
          {/* Success Message */}
          {isFormComplete && (
            <div className="mt-4 p-3 bg-green-50 text-green-700 rounded-md animate-fade-in">
              <div className="flex items-center space-x-2">
                <svg className="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                </svg>
                <span>Form submitted successfully! Thank you for your submission.</span>
              </div>
            </div>
          )}
    
          {/* Form Buttons */}
          <div className="flex justify-between mt-6">
            {step === 1 ? (
              <button
                type="button"
                onClick={onClose}
                className={`btn-secondary ${isSubmitting || isFormComplete ? 'opacity-50 cursor-not-allowed' : ''}`}
                disabled={isSubmitting || isFormComplete}
              >
                Cancel
              </button>
            ) : (
              <button
                type="button"
                onClick={() => setStep(step - 1)}
                className={`btn-secondary ${isSubmitting || isFormComplete ? 'opacity-50 cursor-not-allowed' : ''}`}
                disabled={isSubmitting || isFormComplete}
              >
                Back
              </button>
            )}
    
            {step === 3 ? (
              <button
                type="submit"
                className={`btn-primary ${isSubmitting || isFormComplete ? 'opacity-50 cursor-not-allowed' : ''}`}
                disabled={isSubmitting || isFormComplete}
              >
                {isSubmitting ? 'Submitting...' : 'Submit'}
              </button>
            ) : (
              <button
                type="button"
                onClick={handleNext}
                className={`btn-primary ${isSubmitting || isFormComplete ? 'opacity-50 cursor-not-allowed' : ''}`}
                disabled={isSubmitting || isFormComplete}
              >
                Next
              </button>
            )}
          </div>
        </form>
      </div>
    );
  };
  
  SupplierForm.propTypes = {
    onClose: PropTypes.func.isRequired,
    onSubmit: PropTypes.func.isRequired
  };
  
  export default SupplierForm;